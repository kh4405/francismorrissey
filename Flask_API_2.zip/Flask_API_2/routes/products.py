from flask import Blueprint, request, jsonify
from models import db, Product, Subscription

products_bp = Blueprint("products_bp", __name__, url_prefix="/products")

@products_bp.route("", methods=["GET"])
def get_products():
    products = Product.query.all()
    return jsonify([p.to_dict() for p in products]), 200

@products_bp.route("", methods=["POST"])
def create_product():
    data = request.get_json() or {}
    if "name" not in data or "price" not in data:
        return jsonify({"error":"Missing name or price"}), 400
    p = Product(name=data["name"], price=float(data["price"]), metric_value=data.get("metric_value", 0))
    db.session.add(p)
    db.session.commit()
    return jsonify(p.to_dict()), 201

@products_bp.route("/subscribe", methods=["POST"])
def subscribe():
    data = request.get_json() or {}
    if "email" not in data or "product_id" not in data:
        return jsonify({"error":"Missing email or product_id"}), 400
    s = Subscription(user_email=data["email"], product_id=int(data["product_id"]))
    db.session.add(s)
    db.session.commit()
    # update a simple metric on product (count-like metric)
    prod = Product.query.get(s.product_id)
    if prod:
        prod.metric_value = (prod.metric_value or 0) + 1
        db.session.commit()
    return jsonify(s.to_dict()), 201

@products_bp.route("/metrics", methods=["GET"])
def metrics():
    products = Product.query.all()
    metrics_data = [{"product": p.name, "metric_value": p.metric_value} for p in products]
    return jsonify(metrics_data), 200
