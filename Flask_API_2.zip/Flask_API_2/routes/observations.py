from flask import Blueprint, request, jsonify
from models import db, Observation
from datetime import datetime

observations_bp = Blueprint("observations_bp", __name__, url_prefix="/observations")
REQUIRED_FIELDS = ["timestamp", "timezone", "latitude", "longitude"]

def parse_iso8601(ts: str):
    try:
        # handle "Z" and offsets
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except:
        return None

@observations_bp.route("", methods=["POST"])
def create_observation():
    data = request.get_json() or {}
    missing = [f for f in REQUIRED_FIELDS if f not in data]
    if missing:
        return jsonify({"error": "Missing required fields", "missing": missing}), 400

    ts = parse_iso8601(data["timestamp"])
    if not ts:
        return jsonify({"error": "Invalid timestamp format. Use ISO 8601"}), 400

    try:
        obs = Observation(
            timestamp=ts,
            timezone=data["timezone"],
            latitude=float(data["latitude"]),
            longitude=float(data["longitude"]),
            satellite_id=data.get("satellite_id"),
            spectral_index=data.get("spectral_index"),
            spectral_value=data.get("spectral_value"),
            notes=data.get("notes"),
        )
        db.session.add(obs)
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({"error": "Database error"}), 500

    return jsonify(obs.to_dict()), 201

@observations_bp.route("", methods=["GET"])
def list_observations():
    obs_list = Observation.query.order_by(Observation.timestamp.desc()).all()
    return jsonify([obs.to_dict() for obs in obs_list]), 200

@observations_bp.route("/<int:id>", methods=["GET"])
def get_observation(id):
    obs = Observation.query.get_or_404(id)
    return jsonify(obs.to_dict()), 200

@observations_bp.route("/<int:id>", methods=["DELETE"])
def delete_observation(id):
    obs = Observation.query.get_or_404(id)
    db.session.delete(obs)
    db.session.commit()
    return "", 204
